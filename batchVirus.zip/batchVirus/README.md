Ces scripts ne nécessitent pas de permission admin directe, ils l'obtiennent grâce à ForceAdmin. WDUP, K5 et KILLBOOT ne contiennent pas ForceAdmin, mais ont besoin de permissions administratives pour fonctionner.
*Pour que tout fonctionne parfaitement, Silent-UAC doit être lancé en premier.

Je ne suis en aucun cas responsable de tous actes commis avec ces scripts.

//////////////////////////////////////////////////////////////////////////
-Force Admin : script pour forcer l'invocation d'un cmd Admin et exécuter les commandes dans celui-ci (thanks to catzsec https://github.com/catzsec/ForceAdmin.git)

/////////////////////////////////////////////////////////////////////////

-Silent-UAC (FUD) : force le lancement d'un cmd admin qui :
1 : Désactive le gestionnaire des tâches
2 : Désactive l'UAC

////////////////////////////////////////////////////////////////////////////////////////////

-WDUP :
1 : Supprime et empêche les mises à jour Windows

///////////////////////////////////////////////////////////////////////////////////////////
-SuperFuck :
1 : Désactive le gestionnaire des tâches
2 : Désactive l'accès à la console MMC
3 : Supprime l'accès aux paramètres Windows
4 : Supprime l'accès au panneau de configuration
5 : Supprime l'accès à la fonction run ''exécuter'' (win+r)
6 : Inverse click droit et click gauche
7 : Supprime le menu contextuel du click droit
8 : Désactive les ports clés USB
9 : Met le fond d'écran en noir
10 : Désactive l'affichage des icônes et de l'interaction du bureau
11 : Redémarre

//////////////////////////////////////////////////////////////////////////////////////////

-K5 (discontinued) :
1 : Désactive le gestionnaire des tâches
2 : Désactive le click droit
3 : Désactive l'affichage de la souris
4 : Désactive l'UAC
5 : Désactive les paramètres Windows
6 : Désactive l'accès à la console MMC
7 : Désactive la barre de recherche Windows
8 : Empêche les clés USB d'être branchées
9 : Ajoute un mot de passe au compte utilisateur+admin
10 : Désactive l'affichage des icônes et du bureau et change le fond d'écran
11 : Désactive complètement le PowerShell
12 : Redémarre

/////////////////////////////////////////////////////////////////////////////////////////////
-KILLBOOT (FUD) doit être lancé en admin !!!
1 : Désactive le bureau et les icônes
2 : Met un mot de passe impossible au compte utilisateur et admin
3 : Empêche complètement le PC de booter sur l'OS
4 : Redémarre




/////////////////////////////////////////////////////////
!LEGAL DISCLAMER!

Le créateur ainsi que toutes les personnes associées au développement et à la production de ces scripts ne sont pas responsables
des actions et/ou des dommages causés par l'utilisation de ceux-ci. Vous êtes entièrement responsable de vos actions et vous reconnaissez que ces scripts
ont été créés à des fins éducatives uniquement. 
L'utilisation malveillante de ces scripts est strictement interdite,
tout comme l'utilisation sur un système que vous ne possédez pas ou sur lequel vous n'avez pas obtenu une autorisation explicite d'utilisation.
En utilisant ces scripts, vous acceptez automatiquement les termes ci-dessus et vous déchargez le créateur et toutes les personnes associées à la production de ces scripts de toute responsabilité
en cas de dommage sur votre ordinateur ou tout autre système.




