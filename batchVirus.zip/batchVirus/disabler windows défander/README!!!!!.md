Ces scripts/codes ne sont pas de moi (je ne me rappelle plus d'où ils viennent).

Ces scripts/codes n'ont pas été corrigés, ils fonctionnent mais comportent beaucoup d'erreurs et peuvent ne pas fonctionner à 100%. 

Ils sont là pour faire joli.